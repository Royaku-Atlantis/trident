.\main.exe
exit